﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace doan2
{
    public partial class Form1 : Form
    {

        SqlConnection conn = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();

        }
      
    

    

        

        private void button5_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage7);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage5);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage3);
        }
        public static string username = string.Empty;
        

        private void Form1_Load(object sender, EventArgs e)
        {

           
            danhmuc.DataSource = kn.LayBang("select Ten_DM,Ma_DM from Danh_Muc_Chinh");
            danhmuc.DisplayMember = "Ten_DM";
            danhmuc.ValueMember = "Ma_DM";

            dschinhanh.DataSource = kn.LayBang("select * from Chi_Nhanh");
            dschinhanh.DisplayMember = "Ten_CN";
            dschinhanh.ValueMember = "Ma_CN";

            monan.DataSource = kn.LayBang("select Ma_MA,Ten_MA,Gia_MA,GhiChu from Mon_An");
            danhmuchinh.DataSource = kn.LayBang("select Ten_DM,Ma_DM from Danh_Muc_Chinh");
            danhmuchinh.DisplayMember = "Ten_DM";
            danhmuchinh.ValueMember = "Ma_DM";
            monanchinh.DataSource = kn.LayBang("select Ma_MA,Ten_MA,Gia_MA,GhiChu from Mon_An");
            dataGridView2.DataSource = kn.LayBang("select MA.Ma_MA,MA.Ten_MA,MA.Gia_MA,MA.GhiChu from Mon_An MA,Menu Mn,Chi_Nhanh CN where Mn.Ma_CN=CN.Ma_CN and Mn.Ma_MA=MA.Ma_MA ");

            hnhanvien.DataSource = kn.LayBang("select * from Nhan_Vien");
            if (!string.IsNullOrEmpty(username))
            {
                this.tennva.Text = username;
            }
        }

      

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tab2);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tab1);
        }

     
        string them;
        private void button19_Click(object sender, EventArgs e)
        {

            try
            {
                SqlConnection kn1 = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
                kn1.Open();
                them = "insert into Danh_Muc_chinh values('" + MaDM.Text + "',N'" + TenDM.Text + "')";
                if (them == null)
                {
                    MessageBox.Show("Thêm Không Thành Công");
                }
                SqlCommand comthem = new SqlCommand(them, kn1);
                comthem.ExecuteNonQuery();
                MessageBox.Show("Thêm Thành Công");
                Form1_Load(sender, e);
                MaDM.Clear();
                TenMA.Clear();

            }
            catch
            {
                MessageBox.Show("Thêm Không Thành Công");
            }
            finally
            {
                SqlConnection kn = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
                kn.Close();
            }


        }

      

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }
      
        private void button18_Click_1(object sender, EventArgs e)
        {
            SqlConnection kn1 = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
            kn1.Open();
            them = "insert into Mon_An values('" + MaMA.Text.ToString() + "',N'" + TenMA.Text.ToString() + "','" + GiaMA.Text.ToString() + "','" + danhmuc.SelectedValue.ToString() + "',N'" + GC.Text.ToString() + "')";
         
            if (them == null)
            {
                MessageBox.Show("Thêm Không Thành Công");
            }
            SqlCommand comthem = new SqlCommand(them, kn1);
            comthem.ExecuteNonQuery();
            MessageBox.Show("Thêm Thành Công");
            Form1_Load(sender, e);
            MaMA.Clear();
            TenMA.Clear();
            GiaMA.Clear();
            GC.Clear();
        }

        private void danhmuc_SelectedIndexChanged(object sender, EventArgs e)
        {
            monan.DataSource = kn.LayBang("select Ma_MA,Ten_MA,Gia_MA,GhiChu from Mon_An where Ma_DM='" + danhmuc.SelectedValue.ToString()+"'");
        }

        private void xoama_Click(object sender, EventArgs e)
        {
            kn.ThayDoiDL("delete  from Danh_Muc_Chinh where Ma_DM ='"+ danhmuc.SelectedValue.ToString()+"'");
            Form1_Load(sender, e);
        }

        private void danhmuchinh_SelectedIndexChanged(object sender, EventArgs e)
        {
            monanchinh.DataSource = kn.LayBang("select Ma_MA,Ten_MA,Gia_MA,GhiChu from Mon_An where Ma_DM='" + danhmuchinh.SelectedValue.ToString() + "'");
        }

        private void monan_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void monanchinh_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            SqlConnection kn1 = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
            kn1.Open();
            them = "insert into Chi_Nhanh values('" + macn.Text.ToString() + "',N'" + tencn.Text.ToString() + "','" + sdtcn.Text + "','" + dccn.Text.ToString() + "')";

            if (them == null)
            {
                MessageBox.Show("Thêm Không Thành Công");
            }
            SqlCommand comthem = new SqlCommand(them, kn1);
            comthem.ExecuteNonQuery();
            MessageBox.Show("Thêm Thành Công");
            Form1_Load(sender, e);
            //kn.ThayDoiDL("insert into Chi_Nhanh values('" + macn.Text.ToString() + "',N'" + tencn.Text.ToString() + "','" + sdtcn.Text + "','" + dccn.Text.ToString() + "')");
            //Form1_Load(sender, e);
            //MessageBox.Show("Thêm thành công");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            kn.ThayDoiDL("insert into Menu values('" + macn.Text + "','" + idmam.Text + "')");
            MessageBox.Show("Thêm Thành Công");
            Form1_Load(sender, e);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dschinhanh_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataRowView ht = (DataRowView)dschinhanh.SelectedItem;
            tencn1.Text = ht.Row["Ten_CN"].ToString();
            mcn1.Text = ht.Row["Ma_CN"].ToString();
            dccn1.Text = ht.Row["DiaChi_CN"].ToString();
            sdtcn1.Text = ht.Row["SoDienThoai_CN"].ToString();

            dtgvBill.DataSource = kn.LayBang("select m.Ma_MA, m.Ten_MA, m.Gia_MA, m.GhiChu from Mon_An m,Menu me  where me.Ma_CN = '" + dschinhanh.SelectedValue.ToString()+"' and me.Ma_MA = m.Ma_MA " );
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        string them1;
        private void themnv_Click(object sender, EventArgs e)
        {
            SqlConnection kn2= new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
            kn2.Open();
            them1 = "insert into Nhan_Vien values('" + manv.Text + "','" + idnv.Text + "','" + psnv.Text + "','" + tennv.Text + "','" + cmndnv.Text + "','" + sdtnv.Text + "','" + macnnv.Text + "','" + calamnv.Text + "','" + bpnv.Text + "','" + tnnv.Text + "','" + datanv.Text + "','" + luongnv.Text + "')";
            if (them1 == null)
            {
                MessageBox.Show("Thêm Không Thành Công");
            }
            SqlCommand comthem = new SqlCommand(them1, kn2);
            comthem.ExecuteNonQuery();
            MessageBox.Show("Thêm Thành Công");
            Form1_Load(sender, e);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage6);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage4);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(tabPage10);
        }
    }
}
