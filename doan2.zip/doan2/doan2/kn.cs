﻿    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using System.Data.SqlClient;

    namespace doan2
    {
        class kn
        {   
            static SqlConnection conn = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");
        
    
            public static DataTable LayBang( string sql)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn); 
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable kq = new DataTable();             
                da.Fill(kq);  
                conn.Close();
                return kq;
            }
            public static void ThayDoiDL(string sql)
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();

            }
        }
    }
