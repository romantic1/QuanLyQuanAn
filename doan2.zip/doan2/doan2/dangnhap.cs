﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace doan2
{
    public partial class dangnhap : Form
    {
        public dangnhap()
        {
            InitializeComponent();
        }
        static SqlConnection conn = new SqlConnection(@"Data Source=HOME\SQLEXPRESS;Initial Catalog=QLBANHANG;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            string sql = "select * from Nhan_Vien where ID_NV ='" + dangnh.Text + "' and Password_NV ='" + pass.Text + "' ";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataReader dta = cmd.ExecuteReader();
            if(dta.Read()==true)
            {
                this.Hide();
                Form1 f = new Form1();
                f.ShowDialog();
                this.Close();

                Form1.username = dangnh.Text;
            }
            else
            {
                MessageBox.Show("Đăng không nhập thành công");
            }
        }
    }
}
