﻿namespace doan2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lvBill = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tennva = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab1 = new System.Windows.Forms.TabPage();
            this.monthCalendar2 = new System.Windows.Forms.MonthCalendar();
            this.tab2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dschinhanh = new System.Windows.Forms.ListBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtgvBill = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qLBANHANGDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.qLBANHANGDataSet = new doan2.QLBANHANGDataSet();
            this.sdtcn1 = new System.Windows.Forms.TextBox();
            this.dccn1 = new System.Windows.Forms.TextBox();
            this.mcn1 = new System.Windows.Forms.TextBox();
            this.tencn1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.cbbCategory = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.danhmuchinh = new System.Windows.Forms.ListBox();
            this.monanchinh = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.idmam = new System.Windows.Forms.TextBox();
            this.sdtcn = new System.Windows.Forms.TextBox();
            this.dccn = new System.Windows.Forms.TextBox();
            this.macn = new System.Windows.Forms.TextBox();
            this.tencn = new System.Windows.Forms.TextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.GC = new System.Windows.Forms.TextBox();
            this.GiaMA = new System.Windows.Forms.TextBox();
            this.TenMA = new System.Windows.Forms.TextBox();
            this.MaMA = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.TenDM = new System.Windows.Forms.TextBox();
            this.MaDM = new System.Windows.Forms.TextBox();
            this.themdm = new System.Windows.Forms.Button();
            this.monan = new System.Windows.Forms.DataGridView();
            this.Ma_MA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ten_MA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gia_MA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.danhmuc = new System.Windows.Forms.ListBox();
            this.label30 = new System.Windows.Forms.Label();
            this.button20 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.xoama = new System.Windows.Forms.Button();
            this.suama = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button24 = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.label32 = new System.Windows.Forms.Label();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.listView3 = new System.Windows.Forms.ListView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button25 = new System.Windows.Forms.Button();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.label35 = new System.Windows.Forms.Label();
            this.listView4 = new System.Windows.Forms.ListView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.luongnv = new System.Windows.Forms.TextBox();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.hnhanvien = new System.Windows.Forms.DataGridView();
            this.Ma_NV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ten_NV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CMND = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoDienThoai_NV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Password_NV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ma_CN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CaLam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BoPhan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ThamNien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayBatDauLam = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Luong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button23 = new System.Windows.Forms.Button();
            this.timnv = new System.Windows.Forms.TextBox();
            this.xoanv = new System.Windows.Forms.Button();
            this.suanv = new System.Windows.Forms.Button();
            this.themnv = new System.Windows.Forms.Button();
            this.datanv = new System.Windows.Forms.TextBox();
            this.tnnv = new System.Windows.Forms.TextBox();
            this.bpnv = new System.Windows.Forms.TextBox();
            this.calamnv = new System.Windows.Forms.TextBox();
            this.macnnv = new System.Windows.Forms.TextBox();
            this.psnv = new System.Windows.Forms.TextBox();
            this.idnv = new System.Windows.Forms.TextBox();
            this.sdtnv = new System.Windows.Forms.TextBox();
            this.cmndnv = new System.Windows.Forms.TextBox();
            this.tennv = new System.Windows.Forms.TextBox();
            this.manv = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.listView5 = new System.Windows.Forms.ListView();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.qLBANHANGDataSetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.button14 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tab1.SuspendLayout();
            this.tab2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.monanchinh)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.monan)).BeginInit();
            this.panel3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.panel4.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.panel7.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            this.panel6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.panel5.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hnhanvien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSetBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.lvBill);
            this.panel2.Location = new System.Drawing.Point(805, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(366, 689);
            this.panel2.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 417);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(343, 252);
            this.dataGridView1.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(17, 379);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(265, 20);
            this.label9.TabIndex = 13;
            this.label9.Text = "Các món ăn bán chạy trong tháng:";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.GreenYellow;
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(13, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(343, 204);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Doanh thu bán hàng";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(169, 151);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(168, 24);
            this.textBox4.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(169, 36);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(168, 24);
            this.textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(169, 66);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(168, 24);
            this.textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(169, 119);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(168, 24);
            this.textBox1.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(158, 18);
            this.label8.TabIndex = 3;
            this.label8.Text = "Doanh thu tháng trước:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 157);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 18);
            this.label7.TabIndex = 2;
            this.label7.Text = "Doanh thu tháng này:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(146, 18);
            this.label6.TabIndex = 1;
            this.label6.Text = "Doanh thu hôm qua :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 18);
            this.label5.TabIndex = 0;
            this.label5.Text = "Doanh thu hôm nay :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(69, 44);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(228, 24);
            this.label4.TabIndex = 11;
            this.label4.Text = "TÌNH HÌNH KINH DOANH";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(248, 24);
            this.label3.TabIndex = 9;
            this.label3.Text = "ĐÁNH GIÁ NHANH NHANH";
            // 
            // lvBill
            // 
            this.lvBill.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lvBill.Location = new System.Drawing.Point(7, 4);
            this.lvBill.Margin = new System.Windows.Forms.Padding(4);
            this.lvBill.Name = "lvBill";
            this.lvBill.Size = new System.Drawing.Size(358, 681);
            this.lvBill.TabIndex = 8;
            this.lvBill.UseCompatibleStateImageBehavior = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(694, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1106, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Tên NV:";
            // 
            // tennva
            // 
            this.tennva.AutoSize = true;
            this.tennva.Location = new System.Drawing.Point(1192, 10);
            this.tennva.Name = "tennva";
            this.tennva.Size = new System.Drawing.Size(34, 17);
            this.tennva.TabIndex = 14;
            this.tennva.Text = "Hậu";
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(1097, 4);
            this.listView1.Margin = new System.Windows.Forms.Padding(4);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(260, 36);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(3, 530);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(103, 83);
            this.button5.TabIndex = 9;
            this.button5.Text = "Doanh số bán hàng";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(3, 441);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(103, 83);
            this.button3.TabIndex = 7;
            this.button3.Text = "Xem biểu đồ";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(3, 344);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(103, 91);
            this.button4.TabIndex = 8;
            this.button4.Text = "Thông Tin khách hàng";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(149, 495);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(-892, -22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(134, 113);
            this.button1.TabIndex = 5;
            this.button1.Text = "Chi Nhánh";
            this.button1.UseVisualStyleBackColor = true;
            
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 100);
            this.button2.TabIndex = 6;
            this.button2.Text = "Danh sách món ăn";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(3, 243);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(103, 95);
            this.button6.TabIndex = 10;
            this.button6.Text = "Quản lý khu vực chi nhánh";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab1);
            this.tabControl1.Controls.Add(this.tab2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Location = new System.Drawing.Point(143, 33);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1214, 808);
            this.tabControl1.TabIndex = 16;
            // 
            // tab1
            // 
            this.tab1.BackColor = System.Drawing.Color.Aqua;
            this.tab1.Controls.Add(this.monthCalendar2);
            this.tab1.Controls.Add(this.panel2);
            this.tab1.Controls.Add(this.button1);
            this.tab1.Location = new System.Drawing.Point(4, 25);
            this.tab1.Name = "tab1";
            this.tab1.Padding = new System.Windows.Forms.Padding(3);
            this.tab1.Size = new System.Drawing.Size(1206, 750);
            this.tab1.TabIndex = 0;
            this.tab1.Text = "Chính";
            // 
            // monthCalendar2
            // 
            this.monthCalendar2.Location = new System.Drawing.Point(24, 531);
            this.monthCalendar2.Name = "monthCalendar2";
            this.monthCalendar2.TabIndex = 6;
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.tabControl2);
            this.tab2.Location = new System.Drawing.Point(4, 25);
            this.tab2.Name = "tab2";
            this.tab2.Padding = new System.Windows.Forms.Padding(3);
            this.tab2.Size = new System.Drawing.Size(1206, 750);
            this.tab2.TabIndex = 1;
            this.tab2.Text = "Chi nhánh";
            this.tab2.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl2.Location = new System.Drawing.Point(6, 22);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1197, 722);
            this.tabControl2.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Aqua;
            this.tabPage1.Controls.Add(this.dschinhanh);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.checkBox3);
            this.tabPage1.Controls.Add(this.checkBox2);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.cbbCategory);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 31);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1189, 687);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Thông Tin Chi Nhánh";
            // 
            // dschinhanh
            // 
            this.dschinhanh.FormattingEnabled = true;
            this.dschinhanh.ItemHeight = 22;
            this.dschinhanh.Items.AddRange(new object[] {
            "Chi nhánh 1",
            "",
            "",
            "",
            "Chi nhánh 2",
            "",
            "",
            "",
            "Chi nhánh 3"});
            this.dschinhanh.Location = new System.Drawing.Point(6, 124);
            this.dschinhanh.Name = "dschinhanh";
            this.dschinhanh.Size = new System.Drawing.Size(524, 400);
            this.dschinhanh.TabIndex = 10;
            this.dschinhanh.SelectedIndexChanged += new System.EventHandler(this.dschinhanh_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(581, 100);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(202, 20);
            this.label11.TabIndex = 9;
            this.label11.Text = "Thông Tin từng chi nhánh:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(34, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(179, 20);
            this.label12.TabIndex = 8;
            this.label12.Text = "Thông Tin 3 chi nhánh:";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtgvBill);
            this.panel1.Controls.Add(this.sdtcn1);
            this.panel1.Controls.Add(this.dccn1);
            this.panel1.Controls.Add(this.mcn1);
            this.panel1.Controls.Add(this.tencn1);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Location = new System.Drawing.Point(554, 124);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(595, 476);
            this.panel1.TabIndex = 7;
            // 
            // dtgvBill
            // 
            this.dtgvBill.AllowUserToAddRows = false;
            this.dtgvBill.AllowUserToDeleteRows = false;
            this.dtgvBill.AutoGenerateColumns = false;
            this.dtgvBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvBill.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.dtgvBill.DataSource = this.qLBANHANGDataSetBindingSource;
            this.dtgvBill.Location = new System.Drawing.Point(31, 280);
            this.dtgvBill.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvBill.Name = "dtgvBill";
            this.dtgvBill.ReadOnly = true;
            this.dtgvBill.Size = new System.Drawing.Size(560, 182);
            this.dtgvBill.TabIndex = 28;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Ma_MA";
            this.dataGridViewTextBoxColumn9.HeaderText = "Mã Món Ăn";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Ten_MA";
            this.dataGridViewTextBoxColumn10.HeaderText = "Tên Món Ăn";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Gia_MA";
            this.dataGridViewTextBoxColumn11.HeaderText = "Giá ";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "GhiChu";
            this.dataGridViewTextBoxColumn12.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // qLBANHANGDataSetBindingSource
            // 
            this.qLBANHANGDataSetBindingSource.DataSource = this.qLBANHANGDataSet;
            this.qLBANHANGDataSetBindingSource.Position = 0;
            // 
            // qLBANHANGDataSet
            // 
            this.qLBANHANGDataSet.DataSetName = "QLBANHANGDataSet";
            this.qLBANHANGDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sdtcn1
            // 
            this.sdtcn1.Enabled = false;
            this.sdtcn1.Location = new System.Drawing.Point(166, 164);
            this.sdtcn1.Name = "sdtcn1";
            this.sdtcn1.Size = new System.Drawing.Size(349, 28);
            this.sdtcn1.TabIndex = 21;
            // 
            // dccn1
            // 
            this.dccn1.Enabled = false;
            this.dccn1.Location = new System.Drawing.Point(166, 117);
            this.dccn1.Name = "dccn1";
            this.dccn1.Size = new System.Drawing.Size(349, 28);
            this.dccn1.TabIndex = 20;
            // 
            // mcn1
            // 
            this.mcn1.Enabled = false;
            this.mcn1.Location = new System.Drawing.Point(166, 73);
            this.mcn1.Name = "mcn1";
            this.mcn1.Size = new System.Drawing.Size(349, 28);
            this.mcn1.TabIndex = 19;
            // 
            // tencn1
            // 
            this.tencn1.Enabled = false;
            this.tencn1.Location = new System.Drawing.Point(166, 32);
            this.tencn1.Name = "tencn1";
            this.tencn1.Size = new System.Drawing.Size(349, 28);
            this.tencn1.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(23, 125);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 20);
            this.label13.TabIndex = 17;
            this.label13.Text = "Địa Chỉ:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(23, 247);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 20);
            this.label14.TabIndex = 15;
            this.label14.Text = "Menu";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(23, 81);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 20);
            this.label15.TabIndex = 14;
            this.label15.Text = "Mã Chi Nhánh:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(23, 213);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(0, 20);
            this.label16.TabIndex = 13;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(23, 169);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 20);
            this.label17.TabIndex = 12;
            this.label17.Text = "Số điện thoại:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(23, 40);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 20);
            this.label18.TabIndex = 10;
            this.label18.Text = "Tên chi nhánh:";
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(949, 25);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(140, 37);
            this.button9.TabIndex = 5;
            this.button9.Text = "Tìm";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(299, 249);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 20);
            this.label19.TabIndex = 11;
            this.label19.Text = "Đia chỉ:";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox3.Location = new System.Drawing.Point(730, 38);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(184, 24);
            this.checkBox3.TabIndex = 4;
            this.checkBox3.Text = "Chi nhánh bán chậm";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(471, 38);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(178, 24);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Chi nhánh bán chạy";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(50, 38);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(138, 24);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Chọn Khu Vực";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // cbbCategory
            // 
            this.cbbCategory.FormattingEnabled = true;
            this.cbbCategory.Items.AddRange(new object[] {
            "Quận 1",
            "Quận 2",
            "Quận 3",
            "Quận 4",
            "Quận 5",
            "Quận 6",
            "Quận 7",
            "Quận 8",
            "Quận 9",
            "Quận 10",
            "Quận 11",
            "Quận 12",
            "Quận Thủ Đức",
            "Quận Bình Thạnh",
            "Huyện Hóc Môn",
            "Huyện Nhà Bè",
            "Huyện Cần Giờ",
            "Huyện Bình Chánh",
            "Huyện Chỉ Chi"});
            this.cbbCategory.Location = new System.Drawing.Point(234, 39);
            this.cbbCategory.Margin = new System.Windows.Forms.Padding(4);
            this.cbbCategory.Name = "cbbCategory";
            this.cbbCategory.Size = new System.Drawing.Size(170, 30);
            this.cbbCategory.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Aqua;
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.danhmuchinh);
            this.tabPage2.Controls.Add(this.monanchinh);
            this.tabPage2.Controls.Add(this.button10);
            this.tabPage2.Controls.Add(this.button11);
            this.tabPage2.Controls.Add(this.button12);
            this.tabPage2.Controls.Add(this.idmam);
            this.tabPage2.Controls.Add(this.sdtcn);
            this.tabPage2.Controls.Add(this.dccn);
            this.tabPage2.Controls.Add(this.macn);
            this.tabPage2.Controls.Add(this.tencn);
            this.tabPage2.Controls.Add(this.button13);
            this.tabPage2.Controls.Add(this.button15);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 31);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1189, 687);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Thêm Chi Nhánh";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dataGridView2.DataSource = this.qLBANHANGDataSetBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(15, 367);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(572, 118);
            this.dataGridView2.TabIndex = 42;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Ma_MA";
            this.dataGridViewTextBoxColumn5.HeaderText = "Mã Món Ăn";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Ten_MA";
            this.dataGridViewTextBoxColumn6.HeaderText = "Tên Món Ăn";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Gia_MA";
            this.dataGridViewTextBoxColumn7.HeaderText = "Giá ";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "GhiChu";
            this.dataGridViewTextBoxColumn8.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // danhmuchinh
            // 
            this.danhmuchinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.danhmuchinh.FormattingEnabled = true;
            this.danhmuchinh.ItemHeight = 20;
            this.danhmuchinh.Location = new System.Drawing.Point(657, 56);
            this.danhmuchinh.Name = "danhmuchinh";
            this.danhmuchinh.Size = new System.Drawing.Size(332, 204);
            this.danhmuchinh.TabIndex = 41;
            this.danhmuchinh.SelectedIndexChanged += new System.EventHandler(this.danhmuchinh_SelectedIndexChanged);
            // 
            // monanchinh
            // 
            this.monanchinh.AllowUserToAddRows = false;
            this.monanchinh.AllowUserToDeleteRows = false;
            this.monanchinh.AutoGenerateColumns = false;
            this.monanchinh.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.monanchinh.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.monanchinh.DataSource = this.qLBANHANGDataSetBindingSource;
            this.monanchinh.Location = new System.Drawing.Point(595, 290);
            this.monanchinh.Margin = new System.Windows.Forms.Padding(4);
            this.monanchinh.Name = "monanchinh";
            this.monanchinh.ReadOnly = true;
            this.monanchinh.Size = new System.Drawing.Size(571, 261);
            this.monanchinh.TabIndex = 40;
            this.monanchinh.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.monanchinh_CellContentClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Ma_MA";
            this.dataGridViewTextBoxColumn1.HeaderText = "Mã Món Ăn";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Ten_MA";
            this.dataGridViewTextBoxColumn2.HeaderText = "Tên Món Ăn";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Gia_MA";
            this.dataGridViewTextBoxColumn3.HeaderText = "Giá ";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "GhiChu";
            this.dataGridViewTextBoxColumn4.HeaderText = "Ghi Chú";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(396, 247);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(121, 65);
            this.button10.TabIndex = 39;
            this.button10.Text = "Xóa Chi Nhánh";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(200, 247);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(121, 65);
            this.button11.TabIndex = 39;
            this.button11.Text = "Sửa Chi Nhánh";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(40, 247);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(121, 65);
            this.button12.TabIndex = 38;
            this.button12.Text = "Thêm Chi Nhánh";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // idmam
            // 
            this.idmam.Location = new System.Drawing.Point(297, 511);
            this.idmam.Name = "idmam";
            this.idmam.Size = new System.Drawing.Size(91, 27);
            this.idmam.TabIndex = 36;
            // 
            // sdtcn
            // 
            this.sdtcn.Location = new System.Drawing.Point(200, 186);
            this.sdtcn.Name = "sdtcn";
            this.sdtcn.Size = new System.Drawing.Size(289, 27);
            this.sdtcn.TabIndex = 27;
            // 
            // dccn
            // 
            this.dccn.Location = new System.Drawing.Point(200, 134);
            this.dccn.Name = "dccn";
            this.dccn.Size = new System.Drawing.Size(289, 27);
            this.dccn.TabIndex = 26;
            // 
            // macn
            // 
            this.macn.Location = new System.Drawing.Point(200, 96);
            this.macn.Name = "macn";
            this.macn.Size = new System.Drawing.Size(105, 27);
            this.macn.TabIndex = 24;
            // 
            // tencn
            // 
            this.tencn.Location = new System.Drawing.Point(200, 54);
            this.tencn.Name = "tencn";
            this.tencn.Size = new System.Drawing.Size(289, 27);
            this.tencn.TabIndex = 23;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(286, 569);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(102, 43);
            this.button13.TabIndex = 35;
            this.button13.Text = "Xóa món ăn";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(126, 569);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(102, 43);
            this.button15.TabIndex = 33;
            this.button15.Text = "Thêm món ăn";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(168, 514);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(86, 20);
            this.label21.TabIndex = 31;
            this.label21.Text = "ID món ăn";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(36, 328);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(132, 20);
            this.label22.TabIndex = 30;
            this.label22.Text = "Menu chi nhánh:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(48, 193);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 20);
            this.label24.TabIndex = 21;
            this.label24.Text = "Số Điện Thoại";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(48, 137);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 20);
            this.label25.TabIndex = 20;
            this.label25.Text = "Địa Chỉ";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(663, 11);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 20);
            this.label27.TabIndex = 18;
            this.label27.Text = "Menu Chính:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(48, 96);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(120, 20);
            this.label28.TabIndex = 1;
            this.label28.Text = "Mã Chi Nhánh:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(48, 56);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(125, 20);
            this.label29.TabIndex = 0;
            this.label29.Text = "Tên Chi Nhánh:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Aqua;
            this.tabPage3.Controls.Add(this.button18);
            this.tabPage3.Controls.Add(this.button17);
            this.tabPage3.Controls.Add(this.button16);
            this.tabPage3.Controls.Add(this.label41);
            this.tabPage3.Controls.Add(this.label40);
            this.tabPage3.Controls.Add(this.label39);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.GC);
            this.tabPage3.Controls.Add(this.GiaMA);
            this.tabPage3.Controls.Add(this.TenMA);
            this.tabPage3.Controls.Add(this.MaMA);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.label36);
            this.tabPage3.Controls.Add(this.TenDM);
            this.tabPage3.Controls.Add(this.MaDM);
            this.tabPage3.Controls.Add(this.themdm);
            this.tabPage3.Controls.Add(this.monan);
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Controls.Add(this.button20);
            this.tabPage3.Controls.Add(this.textBox14);
            this.tabPage3.Controls.Add(this.xoama);
            this.tabPage3.Controls.Add(this.suama);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.listView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1206, 750);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Danh Sách Món Ăn";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(950, 29);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(89, 43);
            this.button18.TabIndex = 48;
            this.button18.Text = "Thêm";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click_1);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(950, 88);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(89, 43);
            this.button17.TabIndex = 47;
            this.button17.Text = "Sửa";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(950, 146);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(89, 43);
            this.button16.TabIndex = 46;
            this.button16.Text = "Xóa";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(511, 159);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(59, 17);
            this.label41.TabIndex = 45;
            this.label41.Text = "Ghi Chú";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(511, 131);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(30, 17);
            this.label40.TabIndex = 44;
            this.label40.Text = "Giá";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(511, 101);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(85, 17);
            this.label39.TabIndex = 43;
            this.label39.Text = "Tên Món Ăn";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(511, 73);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(79, 17);
            this.label38.TabIndex = 42;
            this.label38.Text = "Mã Món Ăn";
            // 
            // GC
            // 
            this.GC.Location = new System.Drawing.Point(638, 154);
            this.GC.Name = "GC";
            this.GC.Size = new System.Drawing.Size(220, 22);
            this.GC.TabIndex = 41;
            // 
            // GiaMA
            // 
            this.GiaMA.Location = new System.Drawing.Point(638, 126);
            this.GiaMA.Name = "GiaMA";
            this.GiaMA.Size = new System.Drawing.Size(172, 22);
            this.GiaMA.TabIndex = 40;
            // 
            // TenMA
            // 
            this.TenMA.Location = new System.Drawing.Point(638, 98);
            this.TenMA.Name = "TenMA";
            this.TenMA.Size = new System.Drawing.Size(172, 22);
            this.TenMA.TabIndex = 39;
            // 
            // MaMA
            // 
            this.MaMA.Location = new System.Drawing.Point(638, 70);
            this.MaMA.Name = "MaMA";
            this.MaMA.Size = new System.Drawing.Size(172, 22);
            this.MaMA.TabIndex = 38;
            this.MaMA.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(33, 75);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(101, 17);
            this.label37.TabIndex = 37;
            this.label37.Text = "Tên Danh Mục";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(33, 39);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(95, 17);
            this.label36.TabIndex = 36;
            this.label36.Text = "Mã Danh Mục";
            // 
            // TenDM
            // 
            this.TenDM.Location = new System.Drawing.Point(155, 70);
            this.TenDM.Name = "TenDM";
            this.TenDM.Size = new System.Drawing.Size(172, 22);
            this.TenDM.TabIndex = 35;
            // 
            // MaDM
            // 
            this.MaDM.Location = new System.Drawing.Point(155, 34);
            this.MaDM.Name = "MaDM";
            this.MaDM.Size = new System.Drawing.Size(172, 22);
            this.MaDM.TabIndex = 34;
            // 
            // themdm
            // 
            this.themdm.Location = new System.Drawing.Point(20, 110);
            this.themdm.Name = "themdm";
            this.themdm.Size = new System.Drawing.Size(88, 43);
            this.themdm.TabIndex = 2;
            this.themdm.Text = "Thêm";
            this.themdm.UseVisualStyleBackColor = true;
            this.themdm.Click += new System.EventHandler(this.button19_Click);
            // 
            // monan
            // 
            this.monan.AllowUserToAddRows = false;
            this.monan.AllowUserToDeleteRows = false;
            this.monan.AutoGenerateColumns = false;
            this.monan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.monan.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ma_MA,
            this.Ten_MA,
            this.Gia_MA,
            this.GhiChu});
            this.monan.DataSource = this.qLBANHANGDataSetBindingSource;
            this.monan.Location = new System.Drawing.Point(396, 219);
            this.monan.Margin = new System.Windows.Forms.Padding(4);
            this.monan.Name = "monan";
            this.monan.ReadOnly = true;
            this.monan.Size = new System.Drawing.Size(777, 495);
            this.monan.TabIndex = 27;
            this.monan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.monan_CellContentClick);
            // 
            // Ma_MA
            // 
            this.Ma_MA.DataPropertyName = "Ma_MA";
            this.Ma_MA.HeaderText = "Mã Món Ăn";
            this.Ma_MA.Name = "Ma_MA";
            this.Ma_MA.ReadOnly = true;
            // 
            // Ten_MA
            // 
            this.Ten_MA.DataPropertyName = "Ten_MA";
            this.Ten_MA.HeaderText = "Tên Món Ăn";
            this.Ten_MA.Name = "Ten_MA";
            this.Ten_MA.ReadOnly = true;
            // 
            // Gia_MA
            // 
            this.Gia_MA.DataPropertyName = "Gia_MA";
            this.Gia_MA.HeaderText = "Giá ";
            this.Gia_MA.Name = "Gia_MA";
            this.Gia_MA.ReadOnly = true;
            // 
            // GhiChu
            // 
            this.GhiChu.DataPropertyName = "GhiChu";
            this.GhiChu.HeaderText = "Ghi Chú";
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.ReadOnly = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.danhmuc);
            this.panel3.Controls.Add(this.label30);
            this.panel3.Location = new System.Drawing.Point(58, 216);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(288, 517);
            this.panel3.TabIndex = 26;
            // 
            // danhmuc
            // 
            this.danhmuc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.danhmuc.FormattingEnabled = true;
            this.danhmuc.ItemHeight = 20;
            this.danhmuc.Location = new System.Drawing.Point(27, 63);
            this.danhmuc.Name = "danhmuc";
            this.danhmuc.Size = new System.Drawing.Size(242, 444);
            this.danhmuc.TabIndex = 1;
            this.danhmuc.SelectedIndexChanged += new System.EventHandler(this.danhmuc_SelectedIndexChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(54, 23);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(173, 20);
            this.label30.TabIndex = 0;
            this.label30.Text = "DANH MỤC MÓN ĂN";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(314, 163);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(87, 40);
            this.button20.TabIndex = 33;
            this.button20.Text = "Tìm";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(20, 172);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(279, 22);
            this.textBox14.TabIndex = 32;
            // 
            // xoama
            // 
            this.xoama.Location = new System.Drawing.Point(257, 110);
            this.xoama.Name = "xoama";
            this.xoama.Size = new System.Drawing.Size(89, 43);
            this.xoama.TabIndex = 31;
            this.xoama.Text = "Xóa";
            this.xoama.UseVisualStyleBackColor = true;
            this.xoama.Click += new System.EventHandler(this.xoama_Click);
            // 
            // suama
            // 
            this.suama.Location = new System.Drawing.Point(133, 110);
            this.suama.Name = "suama";
            this.suama.Size = new System.Drawing.Size(89, 43);
            this.suama.TabIndex = 30;
            this.suama.Text = "Sửa";
            this.suama.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(683, 39);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(116, 20);
            this.label31.TabIndex = 28;
            this.label31.Text = "CÁC MÓN ĂN";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.SystemColors.Control;
            this.listView2.Location = new System.Drawing.Point(7, 16);
            this.listView2.Margin = new System.Windows.Forms.Padding(4);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(1178, 717);
            this.listView2.TabIndex = 25;
            this.listView2.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage4
            // 
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1206, 750);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Quản lý khu vực chi nhánh";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Aqua;
            this.tabPage5.Controls.Add(this.button24);
            this.tabPage5.Controls.Add(this.dataGridView5);
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.checkBox8);
            this.tabPage5.Controls.Add(this.panel4);
            this.tabPage5.Controls.Add(this.checkBox10);
            this.tabPage5.Controls.Add(this.checkBox11);
            this.tabPage5.Controls.Add(this.listView3);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1206, 750);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Thông tin khách hàng";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(445, 212);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(143, 73);
            this.button24.TabIndex = 31;
            this.button24.Text = "Báo Cáo";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.DataSource = this.qLBANHANGDataSetBindingSource;
            this.dataGridView5.Location = new System.Drawing.Point(25, 304);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(1157, 385);
            this.dataGridView5.TabIndex = 30;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(515, 44);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(205, 20);
            this.label32.TabIndex = 29;
            this.label32.Text = "BÁO CÁO KHÁCH HÀNG";
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(99, 240);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(146, 21);
            this.checkBox8.TabIndex = 28;
            this.checkBox8.Text = "KHACH HANG VIP\r\n";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox15);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Controls.Add(this.textBox16);
            this.panel4.Controls.Add(this.comboBox2);
            this.panel4.Controls.Add(this.comboBox1);
            this.panel4.Controls.Add(this.textBox17);
            this.panel4.Controls.Add(this.comboBox3);
            this.panel4.Controls.Add(this.checkBox7);
            this.panel4.Controls.Add(this.checkBox6);
            this.panel4.Controls.Add(this.checkBox5);
            this.panel4.Controls.Add(this.checkBox4);
            this.panel4.Controls.Add(this.checkBox9);
            this.panel4.Location = new System.Drawing.Point(661, 115);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(473, 168);
            this.panel4.TabIndex = 27;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(376, 120);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(68, 22);
            this.textBox15.TabIndex = 13;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(321, 125);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(49, 17);
            this.label33.TabIndex = 12;
            this.label33.Text = "Tháng";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(228, 120);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(68, 22);
            this.textBox16.TabIndex = 11;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Tuần 1",
            "Tuần 2",
            "Tuần 3",
            "Tuần 4"});
            this.comboBox2.Location = new System.Drawing.Point(238, 92);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(170, 24);
            this.comboBox2.TabIndex = 10;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Quý 1",
            "Quý 2",
            "Quý 3",
            "Quý 4"});
            this.comboBox1.Location = new System.Drawing.Point(169, 38);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(170, 24);
            this.comboBox1.TabIndex = 9;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(169, 66);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(170, 22);
            this.textBox17.TabIndex = 8;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox3.Location = new System.Drawing.Point(169, 11);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(170, 24);
            this.comboBox3.TabIndex = 5;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(20, 122);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(202, 21);
            this.checkBox7.TabIndex = 4;
            this.checkBox7.Text = "Xem theo ngày trong tháng";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(20, 95);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(199, 21);
            this.checkBox6.TabIndex = 3;
            this.checkBox6.Text = "Xem theo tuần trong tháng";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(20, 68);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(121, 21);
            this.checkBox5.TabIndex = 2;
            this.checkBox5.Text = "Xem theo năm";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(21, 41);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(120, 21);
            this.checkBox4.TabIndex = 1;
            this.checkBox4.Text = "Xem theo Quý";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(20, 14);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(130, 21);
            this.checkBox9.TabIndex = 0;
            this.checkBox9.Text = "Xem theo tháng";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(99, 192);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(244, 21);
            this.checkBox10.TabIndex = 26;
            this.checkBox10.Text = "KHÁCH HÀNG TỪNG CHI NHÁNH\r\n";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(99, 139);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(166, 21);
            this.checkBox11.TabIndex = 25;
            this.checkBox11.Text = "KHÁCH HÀNG TỔNG";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // listView3
            // 
            this.listView3.Location = new System.Drawing.Point(25, 105);
            this.listView3.Margin = new System.Windows.Forms.Padding(4);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(1157, 191);
            this.listView3.TabIndex = 24;
            this.listView3.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tabControl3);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1206, 779);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Xem biểu đồ";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl3.Location = new System.Drawing.Point(27, 25);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1152, 702);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.pictureBox1);
            this.tabPage8.Controls.Add(this.dataGridView8);
            this.tabPage8.Controls.Add(this.panel7);
            this.tabPage8.Location = new System.Drawing.Point(4, 31);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1144, 667);
            this.tabPage8.TabIndex = 0;
            this.tabPage8.Text = "Biểu Đồ bán hàng";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.ErrorImage = global::doan2.Properties.Resources.pinterest_maus_decline;
            this.pictureBox1.InitialImage = global::doan2.Properties.Resources.pinterest_maus_decline;
            this.pictureBox1.Location = new System.Drawing.Point(26, 279);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1099, 350);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView8
            // 
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(12, 261);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.RowTemplate.Height = 24;
            this.dataGridView8.Size = new System.Drawing.Size(1121, 382);
            this.dataGridView8.TabIndex = 3;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Lime;
            this.panel7.Controls.Add(this.textBox22);
            this.panel7.Controls.Add(this.comboBox9);
            this.panel7.Controls.Add(this.comboBox10);
            this.panel7.Controls.Add(this.checkBox22);
            this.panel7.Controls.Add(this.checkBox23);
            this.panel7.Controls.Add(this.checkBox24);
            this.panel7.Location = new System.Drawing.Point(12, 9);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(461, 210);
            this.panel7.TabIndex = 2;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(258, 130);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(132, 28);
            this.textBox22.TabIndex = 8;
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox9.Location = new System.Drawing.Point(258, 75);
            this.comboBox9.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(132, 30);
            this.comboBox9.TabIndex = 7;
            // 
            // comboBox10
            // 
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox10.Location = new System.Drawing.Point(258, 13);
            this.comboBox10.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(132, 30);
            this.comboBox10.TabIndex = 6;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(14, 131);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(197, 28);
            this.checkBox22.TabIndex = 2;
            this.checkBox22.Text = "Doanh số theo năm";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(14, 74);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(191, 28);
            this.checkBox23.TabIndex = 1;
            this.checkBox23.Text = "Doanh số theo quý";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(14, 15);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(207, 28);
            this.checkBox24.TabIndex = 0;
            this.checkBox24.Text = "Doanh số theo tháng";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dataGridView7);
            this.tabPage9.Controls.Add(this.panel6);
            this.tabPage9.Location = new System.Drawing.Point(4, 31);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1144, 667);
            this.tabPage9.TabIndex = 1;
            this.tabPage9.Text = "BIều đồ khách hàng";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Location = new System.Drawing.Point(17, 272);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowTemplate.Height = 24;
            this.dataGridView7.Size = new System.Drawing.Size(1121, 382);
            this.dataGridView7.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Lime;
            this.panel6.Controls.Add(this.textBox21);
            this.panel6.Controls.Add(this.comboBox8);
            this.panel6.Controls.Add(this.comboBox7);
            this.panel6.Controls.Add(this.checkBox21);
            this.panel6.Controls.Add(this.checkBox20);
            this.panel6.Controls.Add(this.checkBox19);
            this.panel6.Location = new System.Drawing.Point(17, 6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(461, 210);
            this.panel6.TabIndex = 0;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(258, 130);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(132, 28);
            this.textBox21.TabIndex = 8;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox8.Location = new System.Drawing.Point(258, 75);
            this.comboBox8.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(132, 30);
            this.comboBox8.TabIndex = 7;
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox7.Location = new System.Drawing.Point(258, 13);
            this.comboBox7.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(132, 30);
            this.comboBox7.TabIndex = 6;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(14, 131);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(218, 28);
            this.checkBox21.TabIndex = 2;
            this.checkBox21.Text = "Khách hàng theo năm";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(14, 74);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(212, 28);
            this.checkBox20.TabIndex = 1;
            this.checkBox20.Text = "Khách hàng theo quý";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(14, 15);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(228, 28);
            this.checkBox19.TabIndex = 0;
            this.checkBox19.Text = "Khách hàng theo tháng";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.Aqua;
            this.tabPage7.Controls.Add(this.button25);
            this.tabPage7.Controls.Add(this.dataGridView6);
            this.tabPage7.Controls.Add(this.panel5);
            this.tabPage7.Controls.Add(this.checkBox17);
            this.tabPage7.Controls.Add(this.checkBox18);
            this.tabPage7.Controls.Add(this.label35);
            this.tabPage7.Controls.Add(this.listView4);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1206, 750);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Doanh Số bán hàng";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(275, 201);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(143, 73);
            this.button25.TabIndex = 28;
            this.button25.Text = "Báo Cáo";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(20, 294);
            this.dataGridView6.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(1157, 385);
            this.dataGridView6.TabIndex = 27;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBox18);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.textBox19);
            this.panel5.Controls.Add(this.comboBox4);
            this.panel5.Controls.Add(this.comboBox5);
            this.panel5.Controls.Add(this.textBox20);
            this.panel5.Controls.Add(this.comboBox6);
            this.panel5.Controls.Add(this.checkBox12);
            this.panel5.Controls.Add(this.checkBox13);
            this.panel5.Controls.Add(this.checkBox14);
            this.panel5.Controls.Add(this.checkBox15);
            this.panel5.Controls.Add(this.checkBox16);
            this.panel5.Location = new System.Drawing.Point(597, 106);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(473, 168);
            this.panel5.TabIndex = 26;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(376, 120);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(68, 22);
            this.textBox18.TabIndex = 13;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(321, 125);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(49, 17);
            this.label34.TabIndex = 12;
            this.label34.Text = "Tháng";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(228, 120);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(68, 22);
            this.textBox19.TabIndex = 11;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Tuần 1",
            "Tuần 2",
            "Tuần 3",
            "Tuần 4"});
            this.comboBox4.Location = new System.Drawing.Point(238, 92);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(170, 24);
            this.comboBox4.TabIndex = 10;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Quý 1",
            "Quý 2",
            "Quý 3",
            "Quý 4"});
            this.comboBox5.Location = new System.Drawing.Point(169, 38);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(170, 24);
            this.comboBox5.TabIndex = 9;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(169, 66);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(170, 22);
            this.textBox20.TabIndex = 8;
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "Tháng 1",
            "Tháng 2",
            "Tháng 3",
            "Tháng 4",
            "Tháng 5",
            "Tháng 6",
            "Tháng 7",
            "Tháng 8",
            "Tháng 9",
            "Tháng 10",
            "Tháng 11",
            "Tháng 12"});
            this.comboBox6.Location = new System.Drawing.Point(169, 11);
            this.comboBox6.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(170, 24);
            this.comboBox6.TabIndex = 5;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(20, 122);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(202, 21);
            this.checkBox12.TabIndex = 4;
            this.checkBox12.Text = "Xem theo ngày trong tháng";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(20, 95);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(199, 21);
            this.checkBox13.TabIndex = 3;
            this.checkBox13.Text = "Xem theo tuần trong tháng";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(20, 68);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(121, 21);
            this.checkBox14.TabIndex = 2;
            this.checkBox14.Text = "Xem theo năm";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(20, 41);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(120, 21);
            this.checkBox15.TabIndex = 1;
            this.checkBox15.Text = "Xem theo Quý";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(20, 14);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(130, 21);
            this.checkBox16.TabIndex = 0;
            this.checkBox16.Text = "Xem theo tháng";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(95, 162);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(302, 21);
            this.checkBox17.TabIndex = 25;
            this.checkBox17.Text = "BÁO CÁO DOANH THU TỪNG CHI NHÁNH\r\n";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(95, 106);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(224, 21);
            this.checkBox18.TabIndex = 24;
            this.checkBox18.Text = "BÁO CÁO DOANH THU TỔNG";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(476, 41);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(193, 20);
            this.label35.TabIndex = 23;
            this.label35.Text = "BÁO CÁO DOANH THU";
            // 
            // listView4
            // 
            this.listView4.Location = new System.Drawing.Point(20, 95);
            this.listView4.Margin = new System.Windows.Forms.Padding(4);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(1157, 191);
            this.listView4.TabIndex = 22;
            this.listView4.UseCompatibleStateImageBehavior = false;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.luongnv);
            this.tabPage10.Controls.Add(this.checkBox26);
            this.tabPage10.Controls.Add(this.checkBox25);
            this.tabPage10.Controls.Add(this.hnhanvien);
            this.tabPage10.Controls.Add(this.button23);
            this.tabPage10.Controls.Add(this.timnv);
            this.tabPage10.Controls.Add(this.xoanv);
            this.tabPage10.Controls.Add(this.suanv);
            this.tabPage10.Controls.Add(this.themnv);
            this.tabPage10.Controls.Add(this.datanv);
            this.tabPage10.Controls.Add(this.tnnv);
            this.tabPage10.Controls.Add(this.bpnv);
            this.tabPage10.Controls.Add(this.calamnv);
            this.tabPage10.Controls.Add(this.macnnv);
            this.tabPage10.Controls.Add(this.psnv);
            this.tabPage10.Controls.Add(this.idnv);
            this.tabPage10.Controls.Add(this.sdtnv);
            this.tabPage10.Controls.Add(this.cmndnv);
            this.tabPage10.Controls.Add(this.tennv);
            this.tabPage10.Controls.Add(this.manv);
            this.tabPage10.Controls.Add(this.label51);
            this.tabPage10.Controls.Add(this.label50);
            this.tabPage10.Controls.Add(this.label49);
            this.tabPage10.Controls.Add(this.label48);
            this.tabPage10.Controls.Add(this.label47);
            this.tabPage10.Controls.Add(this.label46);
            this.tabPage10.Controls.Add(this.label45);
            this.tabPage10.Controls.Add(this.label44);
            this.tabPage10.Controls.Add(this.label43);
            this.tabPage10.Controls.Add(this.label42);
            this.tabPage10.Controls.Add(this.label26);
            this.tabPage10.Controls.Add(this.label23);
            this.tabPage10.Controls.Add(this.label20);
            this.tabPage10.Controls.Add(this.listView5);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1206, 750);
            this.tabPage10.TabIndex = 7;
            this.tabPage10.Text = "Nhân Viên";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // luongnv
            // 
            this.luongnv.Location = new System.Drawing.Point(827, 240);
            this.luongnv.Name = "luongnv";
            this.luongnv.Size = new System.Drawing.Size(184, 22);
            this.luongnv.TabIndex = 60;
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(480, 451);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(96, 21);
            this.checkBox26.TabIndex = 59;
            this.checkBox26.Text = "Chi Nhánh";
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(266, 451);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(49, 21);
            this.checkBox25.TabIndex = 58;
            this.checkBox25.Text = "Mã";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // hnhanvien
            // 
            this.hnhanvien.AutoGenerateColumns = false;
            this.hnhanvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.hnhanvien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ma_NV,
            this.Ten_NV,
            this.CMND,
            this.SoDienThoai_NV,
            this.ID,
            this.Password_NV,
            this.Ma_CN,
            this.CaLam,
            this.BoPhan,
            this.ThamNien,
            this.NgayBatDauLam,
            this.Luong});
            this.hnhanvien.DataSource = this.qLBANHANGDataSetBindingSource;
            this.hnhanvien.Location = new System.Drawing.Point(24, 499);
            this.hnhanvien.Name = "hnhanvien";
            this.hnhanvien.RowTemplate.Height = 24;
            this.hnhanvien.Size = new System.Drawing.Size(1153, 201);
            this.hnhanvien.TabIndex = 57;
            // 
            // Ma_NV
            // 
            this.Ma_NV.DataPropertyName = "Ma_NV";
            this.Ma_NV.HeaderText = "Mã";
            this.Ma_NV.Name = "Ma_NV";
            // 
            // Ten_NV
            // 
            this.Ten_NV.DataPropertyName = "Ten_NV";
            this.Ten_NV.HeaderText = "Tên";
            this.Ten_NV.Name = "Ten_NV";
            // 
            // CMND
            // 
            this.CMND.DataPropertyName = "CMND";
            this.CMND.HeaderText = "CMND";
            this.CMND.Name = "CMND";
            // 
            // SoDienThoai_NV
            // 
            this.SoDienThoai_NV.DataPropertyName = "SoDienThoai_NV";
            this.SoDienThoai_NV.HeaderText = "sdt";
            this.SoDienThoai_NV.Name = "SoDienThoai_NV";
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID_NV";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            // 
            // Password_NV
            // 
            this.Password_NV.DataPropertyName = "Password_NV";
            this.Password_NV.HeaderText = "Password";
            this.Password_NV.Name = "Password_NV";
            // 
            // Ma_CN
            // 
            this.Ma_CN.DataPropertyName = "Ma_CN";
            this.Ma_CN.HeaderText = "Mã chi nhánh";
            this.Ma_CN.Name = "Ma_CN";
            // 
            // CaLam
            // 
            this.CaLam.DataPropertyName = "CaLam";
            this.CaLam.HeaderText = "Ca làm";
            this.CaLam.Name = "CaLam";
            // 
            // BoPhan
            // 
            this.BoPhan.DataPropertyName = "BoPhan";
            this.BoPhan.HeaderText = "Bộ phận";
            this.BoPhan.Name = "BoPhan";
            // 
            // ThamNien
            // 
            this.ThamNien.DataPropertyName = "ThamNien";
            this.ThamNien.HeaderText = "Thâm Niên";
            this.ThamNien.Name = "ThamNien";
            // 
            // NgayBatDauLam
            // 
            this.NgayBatDauLam.DataPropertyName = "NgayBatDauLam";
            this.NgayBatDauLam.HeaderText = "Ngày bắt đầu";
            this.NgayBatDauLam.Name = "NgayBatDauLam";
            // 
            // Luong
            // 
            this.Luong.DataPropertyName = "Luong";
            this.Luong.HeaderText = "Lương";
            this.Luong.Name = "Luong";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(808, 437);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 35);
            this.button23.TabIndex = 56;
            this.button23.Text = "Tìm";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // timnv
            // 
            this.timnv.Location = new System.Drawing.Point(399, 396);
            this.timnv.Name = "timnv";
            this.timnv.Size = new System.Drawing.Size(255, 22);
            this.timnv.TabIndex = 55;
            // 
            // xoanv
            // 
            this.xoanv.Location = new System.Drawing.Point(654, 317);
            this.xoanv.Name = "xoanv";
            this.xoanv.Size = new System.Drawing.Size(125, 60);
            this.xoanv.TabIndex = 54;
            this.xoanv.Text = "Xóa";
            this.xoanv.UseVisualStyleBackColor = true;
            // 
            // suanv
            // 
            this.suanv.Location = new System.Drawing.Point(472, 317);
            this.suanv.Name = "suanv";
            this.suanv.Size = new System.Drawing.Size(124, 60);
            this.suanv.TabIndex = 53;
            this.suanv.Text = "Sửa";
            this.suanv.UseVisualStyleBackColor = true;
            // 
            // themnv
            // 
            this.themnv.Location = new System.Drawing.Point(279, 317);
            this.themnv.Name = "themnv";
            this.themnv.Size = new System.Drawing.Size(117, 60);
            this.themnv.TabIndex = 52;
            this.themnv.Text = "Thêm";
            this.themnv.UseVisualStyleBackColor = true;
            this.themnv.Click += new System.EventHandler(this.themnv_Click);
            // 
            // datanv
            // 
            this.datanv.Location = new System.Drawing.Point(827, 199);
            this.datanv.Name = "datanv";
            this.datanv.Size = new System.Drawing.Size(184, 22);
            this.datanv.TabIndex = 51;
            // 
            // tnnv
            // 
            this.tnnv.Location = new System.Drawing.Point(827, 157);
            this.tnnv.Name = "tnnv";
            this.tnnv.Size = new System.Drawing.Size(184, 22);
            this.tnnv.TabIndex = 49;
            // 
            // bpnv
            // 
            this.bpnv.Location = new System.Drawing.Point(827, 116);
            this.bpnv.Name = "bpnv";
            this.bpnv.Size = new System.Drawing.Size(184, 22);
            this.bpnv.TabIndex = 48;
            // 
            // calamnv
            // 
            this.calamnv.Location = new System.Drawing.Point(480, 243);
            this.calamnv.Name = "calamnv";
            this.calamnv.Size = new System.Drawing.Size(184, 22);
            this.calamnv.TabIndex = 47;
            // 
            // macnnv
            // 
            this.macnnv.Location = new System.Drawing.Point(480, 199);
            this.macnnv.Name = "macnnv";
            this.macnnv.Size = new System.Drawing.Size(184, 22);
            this.macnnv.TabIndex = 46;
            // 
            // psnv
            // 
            this.psnv.Location = new System.Drawing.Point(480, 159);
            this.psnv.Name = "psnv";
            this.psnv.Size = new System.Drawing.Size(184, 22);
            this.psnv.TabIndex = 45;
            // 
            // idnv
            // 
            this.idnv.Location = new System.Drawing.Point(480, 121);
            this.idnv.Name = "idnv";
            this.idnv.Size = new System.Drawing.Size(184, 22);
            this.idnv.TabIndex = 44;
            // 
            // sdtnv
            // 
            this.sdtnv.Location = new System.Drawing.Point(170, 245);
            this.sdtnv.Name = "sdtnv";
            this.sdtnv.Size = new System.Drawing.Size(184, 22);
            this.sdtnv.TabIndex = 43;
            // 
            // cmndnv
            // 
            this.cmndnv.Location = new System.Drawing.Point(170, 199);
            this.cmndnv.Name = "cmndnv";
            this.cmndnv.Size = new System.Drawing.Size(184, 22);
            this.cmndnv.TabIndex = 42;
            // 
            // tennv
            // 
            this.tennv.Location = new System.Drawing.Point(170, 157);
            this.tennv.Name = "tennv";
            this.tennv.Size = new System.Drawing.Size(184, 22);
            this.tennv.TabIndex = 41;
            // 
            // manv
            // 
            this.manv.Location = new System.Drawing.Point(170, 116);
            this.manv.Name = "manv";
            this.manv.Size = new System.Drawing.Size(184, 22);
            this.manv.TabIndex = 40;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(698, 245);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(48, 17);
            this.label51.TabIndex = 39;
            this.label51.Text = "Lương";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(698, 204);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(119, 17);
            this.label50.TabIndex = 38;
            this.label50.Text = "Ngày bắt đầu làm";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(698, 162);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(75, 17);
            this.label49.TabIndex = 37;
            this.label49.Text = "Thâm niên";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(698, 121);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(61, 17);
            this.label48.TabIndex = 36;
            this.label48.Text = "Bộ phận";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(375, 248);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(51, 17);
            this.label47.TabIndex = 35;
            this.label47.Text = "Ca làm";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(375, 204);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(93, 17);
            this.label46.TabIndex = 34;
            this.label46.Text = "Mã chi nhánh";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(57, 248);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(91, 17);
            this.label45.TabIndex = 33;
            this.label45.Text = "Số điện thoại";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(57, 204);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(48, 17);
            this.label44.TabIndex = 32;
            this.label44.Text = "CMND";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(375, 162);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(69, 17);
            this.label43.TabIndex = 31;
            this.label43.Text = "Password";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(375, 121);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 17);
            this.label42.TabIndex = 30;
            this.label42.Text = "ID";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(57, 162);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 17);
            this.label26.TabIndex = 29;
            this.label26.Text = "Tên";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(57, 121);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(31, 17);
            this.label23.TabIndex = 28;
            this.label23.Text = "Mã ";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(475, 44);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(193, 29);
            this.label20.TabIndex = 27;
            this.label20.Text = "Thêm Nhân Viên";
            // 
            // listView5
            // 
            this.listView5.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.listView5.Location = new System.Drawing.Point(7, 7);
            this.listView5.Margin = new System.Windows.Forms.Padding(4);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(1192, 736);
            this.listView5.TabIndex = 26;
            this.listView5.UseCompatibleStateImageBehavior = false;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(12, 9);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(268, 22);
            this.dateTimePicker1.TabIndex = 22;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(3, 37);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(103, 94);
            this.button7.TabIndex = 23;
            this.button7.Text = "Chi Nhánh";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(3, 708);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(134, 108);
            this.button8.TabIndex = 24;
            this.button8.Text = "Màn hình chính";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // qLBANHANGDataSetBindingSource1
            // 
            this.qLBANHANGDataSetBindingSource1.DataSource = this.qLBANHANGDataSet;
            this.qLBANHANGDataSetBindingSource1.Position = 0;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(3, 619);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(103, 83);
            this.button14.TabIndex = 25;
            this.button14.Text = "Nhân Viên";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1379, 853);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.tennva);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Name = "Form1";
            this.Text = "Quản lý bán hàng";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.tab2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvBill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.monanchinh)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.monan)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.hnhanvien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qLBANHANGDataSetBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label tennva;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lvBill;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab1;
        private System.Windows.Forms.TabPage tab2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.MonthCalendar monthCalendar2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.ComboBox cbbCategory;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView monan;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button themdm;
        private System.Windows.Forms.ListBox danhmuc;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button xoama;
        private System.Windows.Forms.Button suama;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.BindingSource qLBANHANGDataSetBindingSource;
        private QLBANHANGDataSet qLBANHANGDataSet;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox TenDM;
        private System.Windows.Forms.TextBox MaDM;
        private System.Windows.Forms.TextBox TenMA;
        private System.Windows.Forms.TextBox MaMA;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox GC;
        private System.Windows.Forms.TextBox GiaMA;
        private System.Windows.Forms.BindingSource qLBANHANGDataSetBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ma_MA;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ten_MA;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gia_MA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
        private System.Windows.Forms.ListBox dschinhanh;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.ListBox danhmuchinh;
        private System.Windows.Forms.DataGridView monanchinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox idmam;
        private System.Windows.Forms.TextBox sdtcn;
        private System.Windows.Forms.TextBox dccn;
        private System.Windows.Forms.TextBox macn;
        private System.Windows.Forms.TextBox tencn;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox sdtcn1;
        private System.Windows.Forms.TextBox dccn1;
        private System.Windows.Forms.TextBox mcn1;
        private System.Windows.Forms.TextBox tencn1;
        private System.Windows.Forms.DataGridView dtgvBill;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridView hnhanvien;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox timnv;
        private System.Windows.Forms.Button xoanv;
        private System.Windows.Forms.Button suanv;
        private System.Windows.Forms.Button themnv;
        private System.Windows.Forms.TextBox datanv;
        private System.Windows.Forms.TextBox tnnv;
        private System.Windows.Forms.TextBox bpnv;
        private System.Windows.Forms.TextBox calamnv;
        private System.Windows.Forms.TextBox macnnv;
        private System.Windows.Forms.TextBox psnv;
        private System.Windows.Forms.TextBox idnv;
        private System.Windows.Forms.TextBox sdtnv;
        private System.Windows.Forms.TextBox cmndnv;
        private System.Windows.Forms.TextBox tennv;
        private System.Windows.Forms.TextBox manv;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ma_NV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ten_NV;
        private System.Windows.Forms.DataGridViewTextBoxColumn CMND;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoDienThoai_NV;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Password_NV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ma_CN;
        private System.Windows.Forms.DataGridViewTextBoxColumn CaLam;
        private System.Windows.Forms.DataGridViewTextBoxColumn BoPhan;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThamNien;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayBatDauLam;
        private System.Windows.Forms.DataGridViewTextBoxColumn Luong;
        private System.Windows.Forms.TextBox luongnv;
    }
}

